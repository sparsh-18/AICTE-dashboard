const express = require("express");
const configViewEngine = require("./configs/viewEngine");
const front = require("./routes/front");
const showInst = require("./routes/showInst");
const editFaculty = require("./routes/editFaculty");
const editInstitute = require("./routes/editInstitute");
const editCourse = require('./routes/editCourse');
const addCourse = require("./routes/addNewCourse");
const addFaculty = require("./routes/addNewFaculty");

let app = express();
configViewEngine(app);

app.use("/", front);
app.use("/", showInst);
app.use("/", editFaculty);
app.use("/", editInstitute);
app.use("/", editCourse);
app.use("/", addCourse);
app.use("/", addFaculty);

app.listen(3000, () => console.log("server started"));
