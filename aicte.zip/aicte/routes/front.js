const express = require("express");
var router = express.Router();
var con = require("../configs/DBcon");

router.get("/", (req, res) => {
  res.render("home", { resp: null, s: "" });
});

router.post("/", (req, res) => {
  if (req.body.srch != null && req.body.srch.length != 0) {
    con.query(
      "Select CURRENT_APPLICATION_ID from instaicte202122 where CURRENT_APPLICATION_ID = ?",
      [req.body.srch],
      (er, re) => {
        if (er) res.render("home", { s: "Not Found" });
        if (re.length != 0) res.redirect("/inst/" + req.body.srch);
        else res.render("home", { s: "Not Found" });
      }
    );
  } else {
    res.render("home", { s: "Not Found" });
  }
});

module.exports = router;
