const express = require("express");
var router = express.Router();
var con = require("../configs/DBcon");

router.post("/inst/:currAppId", (req, res) => {
    const addr = req.body.addr;
    const instname = req.body.instname;
    const inst_reg = req.body.inst_reg;
    const inst_state = req.body.inst_state;
    const inst_dist = req.body.inst_dist;
    const inst_type = req.body.inst_type;
    const womwn_inst = req.body.womwn_inst;
    const mino = req.body.mino;

    if (  //checking the values entered as per database rules
        addr.length <= 410 &&
        instname.length <= 175 &&
        inst_reg.length <= 15 &&
        inst_state.length <= 30 &&
        inst_dist.length <= 40 &&
        inst_type.length <= 30 &&
        womwn_inst.length <= 2 &&
        mino.length <= 5
    ) {
        con.query(
            "Update instaicte202122 set CURRENT_INSTITUTE_ADDRESS = ?, CURRENT_INSTITUTE_NAME = ?, INSTI_REGION = ?, INSTI_STATE = ?, INSTITUTE_DISTRICT = ?, INST_TYPE = ?, WOMEN_INST_FLAG = ?, MINORITY_FLAG = ? where CURRENT_APPLICATION_ID = ?",
            [
                addr,
                instname,
                inst_reg,
                inst_state,
                inst_dist,
                inst_type,
                womwn_inst,
                mino,
                req.params.currAppId,
            ],
            (er, resp) => {
                res.redirect("/inst/" + req.params.currAppId);
            }
        );
    } else {
        res.redirect("/inst/" + req.params.currAppId);
    }
});

module.exports = router;
