const express = require("express");
var router = express.Router();
var con = require("../configs/DBcon");

router.post(
  "/editCourse/:CURRENT_APPLICATION_ID/:LEVEL_OF_COURSE/:COURSE",
  (req, res) => {
    const PROGRAMME = req.body.PROGRAMME;
    const AFFILIATING_UNIVERSITY = req.body.AFFILIATING_UNIVERSITY;
    const SHIFT = req.body.SHIFT;
    let APPROVED_INTAKE = req.body.APPROVED_INTAKE;
    const NO_OF_STUDENTS_PLACED = req.body.NO_OF_STUDENTS_PLACED;
    const X_TOTAL_STUDENTS = req.body.X_TOTAL_STUDENTS;
    if(APPROVED_INTAKE.length == 0) 
      APPROVED_INTAKE = null;
    if (
      PROGRAMME.length <= 50 &&
      AFFILIATING_UNIVERSITY.length <= 100 &&
      SHIFT.length <= 50 &&
      NO_OF_STUDENTS_PLACED.length <= 10 &&
      X_TOTAL_STUDENTS.length <= 50
    ) {
      con.query(
        "UPDATE instaicte202122 SET PROGRAMME = ?, AFFILIATING_UNIVERSITY = ?, SHIFT = ?, APPROVED_INTAKE = ?, NO_OF_STUDENTS_PLACED = ?, X_TOTAL_STUDENTS = ? WHERE CURRENT_APPLICATION_ID = ? AND COURSE = ? AND LEVEL_OF_COURSE = ?",
        [
          PROGRAMME,
          AFFILIATING_UNIVERSITY,
          SHIFT,
          APPROVED_INTAKE,
          NO_OF_STUDENTS_PLACED,
          X_TOTAL_STUDENTS,
          req.params.CURRENT_APPLICATION_ID,
          req.params.COURSE,
          req.params.LEVEL_OF_COURSE,
        ],
        (er, re) => {
         // console.log(er);
        }
      );
    }

    res.redirect("/inst/" + req.params.CURRENT_APPLICATION_ID);
  }
);

router.post(
  "/courseInactive/:CURRENT_APPLICATION_ID/:LEVEL_OF_COURSE/:COURSE",
  (req, res) => {
    con.query(
      "UPDATE instaicte202122 SET ACTIVITY_STATUS = 0 WHERE CURRENT_APPLICATION_ID = ? AND COURSE = ? AND LEVEL_OF_COURSE = ?",
      [
        req.params.CURRENT_APPLICATION_ID,
        req.params.COURSE,
        req.params.LEVEL_OF_COURSE,
      ],
      (er, re) => {}
    );

    res.redirect("/inst/" + req.params.CURRENT_APPLICATION_ID);
  }
);

module.exports = router;
