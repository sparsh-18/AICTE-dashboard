const express = require("express");
//const { promise } = require("../configs/DBcon");
var router = express.Router();
var con = require("../configs/DBcon");

router.get("/inst/:srch", (req, res) => {
  //   con.query(
  //     "SELECT * FROM instaicte202122 INNER JOIN faculty ON instaicte202122.CURRENT_APPLICATION_ID = faculty.CURRENT_APPLICATION_ID WHERE instaicte202122.CURRENT_APPLICATION_ID = ?",
  //     [req.params.srch],
  //     (er, resp) => {
  //       if (er || resp.length == 0)
  //         res.render("institute", { resp: null, s: req.params.srch });

  //       resp.forEach((r) => {
  //         const d = new Date(r.DATE_OF_JOINING);
  //         r.DATE_OF_JOINING =
  //           d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate();
  //       });
  //       console.log(resp);
  //       res.render("institute", { resp: resp, s: req.params.srch });
  //     }
  //   );
  // });

  function getCourses(currAppId) {
    return new Promise((resolve, reject) => {
      con.query(
        "SELECT PROGRAMME, AFFILIATING_UNIVERSITY, LEVEL_OF_COURSE, COURSE, SHIFT, APPROVED_INTAKE, NO_OF_STUDENTS_PLACED, X_TOTAL_STUDENTS from instaicte202122 where CURRENT_APPLICATION_ID = ? AND ACTIVITY_STATUS = 1",
        [currAppId],
        (err, resp) => {
          if (err) return reject(err);
          resolve(resp);
        }
      );
    });
  }

  function getFaculty(currAppId) {
    return new Promise((resolve, reject) => {
      con.query(
        "SELECT * FROM faculty WHERE CURRENT_APPLICATION_ID = ? AND ACTIVITY_STATUS = 1",
        [currAppId],
        (err, resp) => {
          if (err) return reject(err);
          resolve(resp);
        }
      );
    });
  }

  function getInstitute(currAppId) {
    return new Promise((resolve, reject) => {
      con.query(
        "SELECT * FROM instaicte202122 WHERE CURRENT_APPLICATION_ID = ?",
        [currAppId],
        (err, resp) => {
          if (err) return reject(err);
          resolve(resp[0]);
        }
      );
    });
  }


  Promise.all([
    getInstitute(req.params.srch),
    getCourses(req.params.srch),
    getFaculty(req.params.srch),
  ]).then((result) => {
    result[2].forEach((r) => {
      const d = new Date(r.DATE_OF_JOINING);
      r.DATE_OF_JOINING =
        d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate();
    });

    const resp = {
      inst: result[0],
      courses: result[1],
      fac: result[2],
    };
      // console.log(resp.courses);
    res.render("institute", { resp: resp, s: req.params.srch });
  });
});

module.exports = router;
