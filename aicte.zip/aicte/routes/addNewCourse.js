const express = require("express");
var router = express.Router();
var con = require("../configs/DBcon");

router.post(
  "/addNewCourse/:CURRENT_APPLICATION_ID",
  (req, res) => {
    const PROGRAMME = req.body.PROGRAMME;
    const AFFILIATING_UNIVERSITY = req.body.AFFILIATING_UNIVERSITY;
    const SHIFT = req.body.SHIFT;
    let APPROVED_INTAKE = req.body.APPROVED_INTAKE;
    const NO_OF_STUDENTS_PLACED = req.body.NO_OF_STUDENTS_PLACED;
    const X_TOTAL_STUDENTS = req.body.X_TOTAL_STUDENTS;
    const LEVEL_OF_COURSE = req.body.LEVEL_OF_COURSE;
    const COURSE = req.body.COURSE;

    if(APPROVED_INTAKE.length == 0) {
        APPROVED_INTAKE = null;
    }
    
    function getInstitute(currAppId) {
        return new Promise((resolve, reject) => {
          con.query(
            "SELECT PERMANENT_ID, CURRENT_INSTITUTE_ADDRESS, CURRENT_INSTITUTE_NAME, INSTI_REGION, INSTI_STATE, INSTITUTE_DISTRICT, INST_TYPE, WOMEN_INST_FLAG, MINORITY_FLAG FROM instaicte202122 WHERE CURRENT_APPLICATION_ID = ? LIMIT 1",
            [currAppId],
            (err, resp) => {
              if (err) return reject(err);
              resolve(resp[0]);
            }
          );
        });
    }

    getInstitute(req.params.CURRENT_APPLICATION_ID).then((result)=> {
        con.query("INSERT INTO instaicte202122 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ,?, ?, ?, ?, ?, ?, ?, 1)",
        [req.params.CURRENT_APPLICATION_ID, result.PERMANENT_ID, result.CURRENT_INSTITUTE_ADDRESS, result.CURRENT_INSTITUTE_NAME, 
            result.INSTI_REGION, result.INSTI_STATE, result.INSTITUTE_DISTRICT, result.INST_TYPE, result.WOMEN_INST_FLAG, result.MINORITY_FLAG, 
            PROGRAMME, AFFILIATING_UNIVERSITY, LEVEL_OF_COURSE, COURSE, SHIFT,APPROVED_INTAKE, 
        NO_OF_STUDENTS_PLACED, X_TOTAL_STUDENTS], 
        (er, r) => {
            if(er) console.log(er);
        })
    })

    res.redirect("/inst/" + req.params.CURRENT_APPLICATION_ID);
  }
);


module.exports = router;
