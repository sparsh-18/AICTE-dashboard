const express = require("express");
var router = express.Router();
var con = require("../configs/DBcon");

router.post(
  "/addNewFaculty",
  (req, res) => {
    const CURRENT_APPLICATION_ID = req.body.CURRENT_APPLICATION_ID;
    const FACULTY_UNIQUE_ID = req.body.FACULTY_UNIQUE_ID;
    const NAME = req.body.NAME;
    let GENDER = req.body.GENDER;
    const EXACT_DESIGNATION = req.body.EXACT_DESIGNATION;
    const DATE_OF_JOINING = req.body.DATE_OF_JOINING;
    const AREAS_OF_SPECIALISATION = req.body.AREAS_OF_SPECIALISATION;
    const APPOINTMENT_TYPE = req.body.APPOINTMENT_TYPE;


    function getInstitute(currAppId) {
        return new Promise((resolve, reject) => {
          con.query(
            "SELECT * FROM instaicte202122 WHERE CURRENT_APPLICATION_ID = ? LIMIT 1",
            [currAppId],
            (err, resp) => {
                if (err) return reject(err);
                if(resp.length > 0) resolve(true);
                else resolve(false)
            }
          );
        });
    }

    function getFaculty(falId) {
        return new Promise((resolve, reject) => {
          con.query(
            "SELECT * FROM faculty WHERE FACULTY_UNIQUE_ID = ? LIMIT 1",
            [falId],
            (err, resp) => {
                if (err) return reject(err);
                if(resp.length > 0) resolve(true);
                else resolve(false)
            }
          );
        });
    }

    //checking if institute is valid or not entered
    getInstitute(req.params.CURRENT_APPLICATION_ID).then((resultIns)=> {
        // checking if faculty id unique or not
        getFaculty(FACULTY_UNIQUE_ID).then((resultFac) => {

            if ((resultIns || CURRENT_APPLICATION_ID.length == 0) && !resultFac) {
                
                con.query("insert into faculty values (?,?,?,?,?,?,?,?,0)",
                    [CURRENT_APPLICATION_ID, FACULTY_UNIQUE_ID, NAME, GENDER, EXACT_DESIGNATION, DATE_OF_JOINING, AREAS_OF_SPECIALISATION, APPOINTMENT_TYPE],
                    (er, re) => { })
            }
        })
    })

   res.redirect("/faculties");
  }
);


module.exports = router;
