const express = require("express");
var router = express.Router();
var con = require("../configs/DBcon");

// edit faculty
router.post("/editfalc/:falid", (req, res) => {
  if (
    //checking the values entered as per database rules
    req.body.name.length <= 100 &&
    req.body.gender.length <= 10 &&
    req.body.desg.length <= 15 &&
    req.body.specialization.length <= 30 &&
    req.body.type.length <= 15
  ) {
    //console.log(req.body.date);
    con.query(
      "Update faculty set NAME = ?, GENDER = ?, EXACT_DESIGNATION = ?, DATE_OF_JOINING = ?, AREAS_OF_SPECIALISATION = ?, APPOINTMENT_TYPE = ? where FACULTY_UNIQUE_ID = ?",
      [
        req.body.name,
        req.body.gender,
        req.body.desg,
        req.body.date,
        req.body.specialization,
        req.body.type,
        req.params.falid,
      ],
      (err, resp) => {
        // if (err) console.log(err);
        res.redirect("/inst/" + req.body.mainid);
      }
    );
  } else {
    res.redirect("/inst/" + req.body.mainid);
  }
});

// convert faculty to inactive
router.post("/facultyInactive/:currAppId/:falid", (req, res) => {
  con.query(
    "UPDATE faculty SET ACTIVITY_STATUS = 0 WHERE FACULTY_UNIQUE_ID = ?",
    [req.params.falid],
    (er, r) => {
      res.redirect("/inst/" + req.params.currAppId);
    }
  );
});


//show inactive faculty
router.get("/faculties", (req, res) => {
  con.query("SELECT * from faculty WHERE ACTIVITY_STATUS = 0", (err,result) => {
    if(err) 
      console.log(err);

    result.forEach((r) => {
      const d = new Date(r.DATE_OF_JOINING);
      r.DATE_OF_JOINING =
        d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate();
    });
    res.render("faculties", {resp: result})
  });
});

// reactive faculty
router.post("/facultyReActive/:facUnqId", (req,res) => {

  con.query("Select CURRENT_APPLICATION_ID from faculty where FACULTY_UNIQUE_ID = ?",[req.params.facUnqId],(er, resp)=>{
   // console.log(resp);
    if(resp[0].CURRENT_APPLICATION_ID.length > 0) {
      con.query("UPDATE faculty SET ACTIVITY_STATUS = 1 WHERE FACULTY_UNIQUE_ID = ?",[req.params.facUnqId],(er, r) => {
      //  if(er)
    //      console.log(er);
        });
      }
    })
    
    res.redirect("/faculties");
});

// edit inactive faculty
router.post("/editInactiveFalc/:falid", (req, res) => {
 
  //checking if CURRENT APP ID of institute is valid
  function getInstitute(currAppId) {
    return new Promise((resolve, reject) => {
      con.query(
        "SELECT * FROM instaicte202122 WHERE CURRENT_APPLICATION_ID = ? LIMIT 1",
        [currAppId],
        (err, resp) => {
         // console.log(err);
          if (err) return reject(err);
          if(resp.length > 0) resolve(true);
          else resolve(false)
        }
      );
    });
  }

  //let isInstValid = false;
  getInstitute(req.body.CURRENT_APPLICATION_ID).then((isInstValid) => {
    //isInstValid = res;

    if (
      //checking the values entered as per database rules
      req.body.name.length <= 100 &&
      req.body.gender.length <= 10 &&
      req.body.desg.length <= 15 &&
      req.body.specialization.length <= 30 &&
      req.body.type.length <= 15 &&
      isInstValid
    ) {
      //console.log(req.body.date);
      con.query(
        "Update faculty set CURRENT_APPLICATION_ID = ?, NAME = ?, GENDER = ?, EXACT_DESIGNATION = ?, DATE_OF_JOINING = ?, AREAS_OF_SPECIALISATION = ?, APPOINTMENT_TYPE = ? where FACULTY_UNIQUE_ID = ?",
        [
          req.body.CURRENT_APPLICATION_ID,
          req.body.name,
          req.body.gender,
          req.body.desg,
          req.body.date,
          req.body.specialization,
          req.body.type,
          req.params.falid,
        ],
        (err, resp) => {
          // if (err) console.log(err);
          //res.redirect("/faculties");
        }
      );
    }
  });

  res.redirect("/faculties");
});
module.exports = router;
